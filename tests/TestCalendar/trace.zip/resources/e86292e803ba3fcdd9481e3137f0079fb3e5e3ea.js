(function () {self.onmessage = function (message) {(function (options, done) {
            const filterInstructions = options.filterInstructions;
            const imageData = options.imageData;
            ((err, imageData) => {
                ((e,t)=>{const{imageData:n,amount:r=1}=e,o=Math.round(Math.max(1,r)*2),i=Math.round(o*.5),s=n.width,a=n.height,l=new Uint8ClampedArray(s*a*4),c=n.data;let u,d=0,f,p,g,m=0,S=0,y;const b=s*a*4-4;for(p=0;p<a;p++)for(u=crypto.getRandomValues(new Uint8ClampedArray(a)),f=0;f<s;f++)g=u[p]/255,m=0,S=0,g<.5&&(m=(-i+Math.round(Math.random()*o))*4),g>.5&&(S=(-i+Math.round(Math.random()*o))*(s*4)),y=Math.min(Math.max(0,d+m+S),b),l[d]=c[y],l[d+1]=c[y+1],l[d+2]=c[y+2],l[d+3]=c[y+3],d+=4;t(null,{data:l,width:n.width,height:n.height})})(Object.assign({ imageData: imageData }, filterInstructions[0]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((k,M)=>k+M);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let p=0,g=0,m=0,S=0,y=0,b=0,_=0,E=0,I=0,x=0;const R=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(p=0,g=0,m=0,S=0,b=0;b<d;b++)for(y=0;y<d;y++)_=u+b-f,E=c+y-f,_<0&&(_=s-1),_>=s&&(_=0),E<0&&(E=i-1),E>=i&&(E=0),I=(_*i+E)*4,x=r[b*d+y],p+=a[I]*x,g+=a[I+1]*x,m+=a[I+2]*x,S+=a[I+3]*x;R[l]=p/o,R[l+1]=g/o,R[l+2]=m/o,R[l+3]=S/o,l+=4}t(null,{data:R,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[1]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((k,M)=>k+M);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let p=0,g=0,m=0,S=0,y=0,b=0,_=0,E=0,I=0,x=0;const R=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(p=0,g=0,m=0,S=0,b=0;b<d;b++)for(y=0;y<d;y++)_=u+b-f,E=c+y-f,_<0&&(_=s-1),_>=s&&(_=0),E<0&&(E=i-1),E>=i&&(E=0),I=(_*i+E)*4,x=r[b*d+y],p+=a[I]*x,g+=a[I+1]*x,m+=a[I+2]*x,S+=a[I+3]*x;R[l]=p/o,R[l+1]=g/o,R[l+2]=m/o,R[l+3]=S/o,l+=4}t(null,{data:R,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[2]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((k,M)=>k+M);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let p=0,g=0,m=0,S=0,y=0,b=0,_=0,E=0,I=0,x=0;const R=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(p=0,g=0,m=0,S=0,b=0;b<d;b++)for(y=0;y<d;y++)_=u+b-f,E=c+y-f,_<0&&(_=s-1),_>=s&&(_=0),E<0&&(E=i-1),E>=i&&(E=0),I=(_*i+E)*4,x=r[b*d+y],p+=a[I]*x,g+=a[I+1]*x,m+=a[I+2]*x,S+=a[I+3]*x;R[l]=p/o,R[l+1]=g/o,R[l+2]=m/o,R[l+3]=S/o,l+=4}t(null,{data:R,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[3]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((k,M)=>k+M);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let p=0,g=0,m=0,S=0,y=0,b=0,_=0,E=0,I=0,x=0;const R=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(p=0,g=0,m=0,S=0,b=0;b<d;b++)for(y=0;y<d;y++)_=u+b-f,E=c+y-f,_<0&&(_=s-1),_>=s&&(_=0),E<0&&(E=i-1),E>=i&&(E=0),I=(_*i+E)*4,x=r[b*d+y],p+=a[I]*x,g+=a[I+1]*x,m+=a[I+2]*x,S+=a[I+3]*x;R[l]=p/o,R[l+1]=g/o,R[l+2]=m/o,R[l+3]=S/o,l+=4}t(null,{data:R,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[4]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((k,M)=>k+M);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let p=0,g=0,m=0,S=0,y=0,b=0,_=0,E=0,I=0,x=0;const R=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(p=0,g=0,m=0,S=0,b=0;b<d;b++)for(y=0;y<d;y++)_=u+b-f,E=c+y-f,_<0&&(_=s-1),_>=s&&(_=0),E<0&&(E=i-1),E>=i&&(E=0),I=(_*i+E)*4,x=r[b*d+y],p+=a[I]*x,g+=a[I+1]*x,m+=a[I+2]*x,S+=a[I+3]*x;R[l]=p/o,R[l+1]=g/o,R[l+2]=m/o,R[l+3]=S/o,l+=4}t(null,{data:R,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[5]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((k,M)=>k+M);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let p=0,g=0,m=0,S=0,y=0,b=0,_=0,E=0,I=0,x=0;const R=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(p=0,g=0,m=0,S=0,b=0;b<d;b++)for(y=0;y<d;y++)_=u+b-f,E=c+y-f,_<0&&(_=s-1),_>=s&&(_=0),E<0&&(E=i-1),E>=i&&(E=0),I=(_*i+E)*4,x=r[b*d+y],p+=a[I]*x,g+=a[I+1]*x,m+=a[I+2]*x,S+=a[I+3]*x;R[l]=p/o,R[l+1]=g/o,R[l+2]=m/o,R[l+3]=S/o,l+=4}t(null,{data:R,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[6]), 
                    done)
            })
            })
            })
            })
            })
            })
            })(null, imageData)
        }).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()