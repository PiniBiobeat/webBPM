(function () {self.onmessage = function (message) {(function (options, done) {
            const filterInstructions = options.filterInstructions;
            const imageData = options.imageData;
            ((err, imageData) => {
                ((e,t)=>{const{imageData:n,amount:r=1}=e,o=Math.round(Math.max(1,r)*2),i=Math.round(o*.5),s=n.width,a=n.height,l=new Uint8ClampedArray(s*a*4),c=n.data;let u,d=0,f,h,p,m=0,v=0,g;const y=s*a*4-4;for(h=0;h<a;h++)for(u=crypto.getRandomValues(new Uint8ClampedArray(a)),f=0;f<s;f++)p=u[h]/255,m=0,v=0,p<.5&&(m=(-i+Math.round(Math.random()*o))*4),p>.5&&(v=(-i+Math.round(Math.random()*o))*(s*4)),g=Math.min(Math.max(0,d+m+v),y),l[d]=c[g],l[d+1]=c[g+1],l[d+2]=c[g+2],l[d+3]=c[g+3],d+=4;t(null,{data:l,width:n.width,height:n.height})})(Object.assign({ imageData: imageData }, filterInstructions[0]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((R,A)=>R+A);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,p=0,m=0,v=0,g=0,y=0,b=0,S=0,T=0,E=0;const C=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,p=0,m=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,E=r[y*d+g],h+=a[T]*E,p+=a[T+1]*E,m+=a[T+2]*E,v+=a[T+3]*E;C[l]=h/o,C[l+1]=p/o,C[l+2]=m/o,C[l+3]=v/o,l+=4}t(null,{data:C,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[1]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((R,A)=>R+A);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,p=0,m=0,v=0,g=0,y=0,b=0,S=0,T=0,E=0;const C=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,p=0,m=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,E=r[y*d+g],h+=a[T]*E,p+=a[T+1]*E,m+=a[T+2]*E,v+=a[T+3]*E;C[l]=h/o,C[l+1]=p/o,C[l+2]=m/o,C[l+3]=v/o,l+=4}t(null,{data:C,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[2]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((R,A)=>R+A);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,p=0,m=0,v=0,g=0,y=0,b=0,S=0,T=0,E=0;const C=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,p=0,m=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,E=r[y*d+g],h+=a[T]*E,p+=a[T+1]*E,m+=a[T+2]*E,v+=a[T+3]*E;C[l]=h/o,C[l+1]=p/o,C[l+2]=m/o,C[l+3]=v/o,l+=4}t(null,{data:C,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[3]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((R,A)=>R+A);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,p=0,m=0,v=0,g=0,y=0,b=0,S=0,T=0,E=0;const C=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,p=0,m=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,E=r[y*d+g],h+=a[T]*E,p+=a[T+1]*E,m+=a[T+2]*E,v+=a[T+3]*E;C[l]=h/o,C[l+1]=p/o,C[l+2]=m/o,C[l+3]=v/o,l+=4}t(null,{data:C,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[4]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((R,A)=>R+A);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,p=0,m=0,v=0,g=0,y=0,b=0,S=0,T=0,E=0;const C=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,p=0,m=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,E=r[y*d+g],h+=a[T]*E,p+=a[T+1]*E,m+=a[T+2]*E,v+=a[T+3]*E;C[l]=h/o,C[l+1]=p/o,C[l+2]=m/o,C[l+3]=v/o,l+=4}t(null,{data:C,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[5]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((R,A)=>R+A);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,p=0,m=0,v=0,g=0,y=0,b=0,S=0,T=0,E=0;const C=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,p=0,m=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,E=r[y*d+g],h+=a[T]*E,p+=a[T+1]*E,m+=a[T+2]*E,v+=a[T+3]*E;C[l]=h/o,C[l+1]=p/o,C[l+2]=m/o,C[l+3]=v/o,l+=4}t(null,{data:C,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[6]), 
                    done)
            })
            })
            })
            })
            })
            })
            })(null, imageData)
        }).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()