(function () {self.onmessage = function (message) {(function (options, done) {
            const filterInstructions = options.filterInstructions;
            const imageData = options.imageData;
            ((err, imageData) => {
                ((e,t)=>{const{imageData:n,amount:r=1}=e,o=Math.round(Math.max(1,r)*2),i=Math.round(o*.5),s=n.width,a=n.height,l=new Uint8ClampedArray(s*a*4),c=n.data;let u,d=0,f,h,m,g=0,v=0,p;const y=s*a*4-4;for(h=0;h<a;h++)for(u=crypto.getRandomValues(new Uint8ClampedArray(a)),f=0;f<s;f++)m=u[h]/255,g=0,v=0,m<.5&&(g=(-i+Math.round(Math.random()*o))*4),m>.5&&(v=(-i+Math.round(Math.random()*o))*(s*4)),p=Math.min(Math.max(0,d+g+v),y),l[d]=c[p],l[d+1]=c[p+1],l[d+2]=c[p+2],l[d+3]=c[p+3],d+=4;t(null,{data:l,width:n.width,height:n.height})})(Object.assign({ imageData: imageData }, filterInstructions[0]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((P,R)=>P+R);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,g=0,v=0,p=0,y=0,b=0,S=0,x=0,C=0;const E=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,m=0,g=0,v=0,y=0;y<d;y++)for(p=0;p<d;p++)b=u+y-f,S=c+p-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),x=(b*i+S)*4,C=r[y*d+p],h+=a[x]*C,m+=a[x+1]*C,g+=a[x+2]*C,v+=a[x+3]*C;E[l]=h/o,E[l+1]=m/o,E[l+2]=g/o,E[l+3]=v/o,l+=4}t(null,{data:E,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[1]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((P,R)=>P+R);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,g=0,v=0,p=0,y=0,b=0,S=0,x=0,C=0;const E=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,m=0,g=0,v=0,y=0;y<d;y++)for(p=0;p<d;p++)b=u+y-f,S=c+p-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),x=(b*i+S)*4,C=r[y*d+p],h+=a[x]*C,m+=a[x+1]*C,g+=a[x+2]*C,v+=a[x+3]*C;E[l]=h/o,E[l+1]=m/o,E[l+2]=g/o,E[l+3]=v/o,l+=4}t(null,{data:E,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[2]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((P,R)=>P+R);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,g=0,v=0,p=0,y=0,b=0,S=0,x=0,C=0;const E=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,m=0,g=0,v=0,y=0;y<d;y++)for(p=0;p<d;p++)b=u+y-f,S=c+p-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),x=(b*i+S)*4,C=r[y*d+p],h+=a[x]*C,m+=a[x+1]*C,g+=a[x+2]*C,v+=a[x+3]*C;E[l]=h/o,E[l+1]=m/o,E[l+2]=g/o,E[l+3]=v/o,l+=4}t(null,{data:E,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[3]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((P,R)=>P+R);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,g=0,v=0,p=0,y=0,b=0,S=0,x=0,C=0;const E=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,m=0,g=0,v=0,y=0;y<d;y++)for(p=0;p<d;p++)b=u+y-f,S=c+p-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),x=(b*i+S)*4,C=r[y*d+p],h+=a[x]*C,m+=a[x+1]*C,g+=a[x+2]*C,v+=a[x+3]*C;E[l]=h/o,E[l+1]=m/o,E[l+2]=g/o,E[l+3]=v/o,l+=4}t(null,{data:E,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[4]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((P,R)=>P+R);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,g=0,v=0,p=0,y=0,b=0,S=0,x=0,C=0;const E=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,m=0,g=0,v=0,y=0;y<d;y++)for(p=0;p<d;p++)b=u+y-f,S=c+p-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),x=(b*i+S)*4,C=r[y*d+p],h+=a[x]*C,m+=a[x+1]*C,g+=a[x+2]*C,v+=a[x+3]*C;E[l]=h/o,E[l+1]=m/o,E[l+2]=g/o,E[l+3]=v/o,l+=4}t(null,{data:E,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[5]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((P,R)=>P+R);o=o<=0?1:o;const i=n.width,s=n.height,a=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,g=0,v=0,p=0,y=0,b=0,S=0,x=0,C=0;const E=new Uint8ClampedArray(i*s*4);for(u=0;u<s;u++)for(c=0;c<i;c++){for(h=0,m=0,g=0,v=0,y=0;y<d;y++)for(p=0;p<d;p++)b=u+y-f,S=c+p-f,b<0&&(b=s-1),b>=s&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),x=(b*i+S)*4,C=r[y*d+p],h+=a[x]*C,m+=a[x+1]*C,g+=a[x+2]*C,v+=a[x+3]*C;E[l]=h/o,E[l+1]=m/o,E[l+2]=g/o,E[l+3]=v/o,l+=4}t(null,{data:E,width:i,height:s})})(Object.assign({ imageData: imageData }, filterInstructions[6]), 
                    done)
            })
            })
            })
            })
            })
            })
            })(null, imageData)
        }).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()