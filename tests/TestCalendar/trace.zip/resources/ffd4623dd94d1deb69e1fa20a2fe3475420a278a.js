(function () {self.onmessage = function (message) {(function (options, done) {
            const filterInstructions = options.filterInstructions;
            const imageData = options.imageData;
            ((err, imageData) => {
                ((e,t)=>{const{imageData:n,amount:r=1}=e,o=Math.round(Math.max(1,r)*2),i=Math.round(o*.5),a=n.width,s=n.height,l=new Uint8ClampedArray(a*s*4),c=n.data;let u,d=0,f,h,m,p=0,v=0,g;const y=a*s*4-4;for(h=0;h<s;h++)for(u=crypto.getRandomValues(new Uint8ClampedArray(s)),f=0;f<a;f++)m=u[h]/255,p=0,v=0,m<.5&&(p=(-i+Math.round(Math.random()*o))*4),m>.5&&(v=(-i+Math.round(Math.random()*o))*(a*4)),g=Math.min(Math.max(0,d+p+v),y),l[d]=c[g],l[d+1]=c[g+1],l[d+2]=c[g+2],l[d+3]=c[g+3],d+=4;t(null,{data:l,width:n.width,height:n.height})})(Object.assign({ imageData: imageData }, filterInstructions[0]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((I,R)=>I+R);o=o<=0?1:o;const i=n.width,a=n.height,s=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,p=0,v=0,g=0,y=0,b=0,S=0,T=0,C=0;const x=new Uint8ClampedArray(i*a*4);for(u=0;u<a;u++)for(c=0;c<i;c++){for(h=0,m=0,p=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=a-1),b>=a&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,C=r[y*d+g],h+=s[T]*C,m+=s[T+1]*C,p+=s[T+2]*C,v+=s[T+3]*C;x[l]=h/o,x[l+1]=m/o,x[l+2]=p/o,x[l+3]=v/o,l+=4}t(null,{data:x,width:i,height:a})})(Object.assign({ imageData: imageData }, filterInstructions[1]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((I,R)=>I+R);o=o<=0?1:o;const i=n.width,a=n.height,s=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,p=0,v=0,g=0,y=0,b=0,S=0,T=0,C=0;const x=new Uint8ClampedArray(i*a*4);for(u=0;u<a;u++)for(c=0;c<i;c++){for(h=0,m=0,p=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=a-1),b>=a&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,C=r[y*d+g],h+=s[T]*C,m+=s[T+1]*C,p+=s[T+2]*C,v+=s[T+3]*C;x[l]=h/o,x[l+1]=m/o,x[l+2]=p/o,x[l+3]=v/o,l+=4}t(null,{data:x,width:i,height:a})})(Object.assign({ imageData: imageData }, filterInstructions[2]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((I,R)=>I+R);o=o<=0?1:o;const i=n.width,a=n.height,s=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,p=0,v=0,g=0,y=0,b=0,S=0,T=0,C=0;const x=new Uint8ClampedArray(i*a*4);for(u=0;u<a;u++)for(c=0;c<i;c++){for(h=0,m=0,p=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=a-1),b>=a&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,C=r[y*d+g],h+=s[T]*C,m+=s[T+1]*C,p+=s[T+2]*C,v+=s[T+3]*C;x[l]=h/o,x[l+1]=m/o,x[l+2]=p/o,x[l+3]=v/o,l+=4}t(null,{data:x,width:i,height:a})})(Object.assign({ imageData: imageData }, filterInstructions[3]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((I,R)=>I+R);o=o<=0?1:o;const i=n.width,a=n.height,s=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,p=0,v=0,g=0,y=0,b=0,S=0,T=0,C=0;const x=new Uint8ClampedArray(i*a*4);for(u=0;u<a;u++)for(c=0;c<i;c++){for(h=0,m=0,p=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=a-1),b>=a&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,C=r[y*d+g],h+=s[T]*C,m+=s[T+1]*C,p+=s[T+2]*C,v+=s[T+3]*C;x[l]=h/o,x[l+1]=m/o,x[l+2]=p/o,x[l+3]=v/o,l+=4}t(null,{data:x,width:i,height:a})})(Object.assign({ imageData: imageData }, filterInstructions[4]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((I,R)=>I+R);o=o<=0?1:o;const i=n.width,a=n.height,s=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,p=0,v=0,g=0,y=0,b=0,S=0,T=0,C=0;const x=new Uint8ClampedArray(i*a*4);for(u=0;u<a;u++)for(c=0;c<i;c++){for(h=0,m=0,p=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=a-1),b>=a&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,C=r[y*d+g],h+=s[T]*C,m+=s[T+1]*C,p+=s[T+2]*C,v+=s[T+3]*C;x[l]=h/o,x[l+1]=m/o,x[l+2]=p/o,x[l+3]=v/o,l+=4}t(null,{data:x,width:i,height:a})})(Object.assign({ imageData: imageData }, filterInstructions[5]), 
                    (err, imageData) => {
                ((e,t)=>{const{imageData:n,matrix:r}=e;if(!r)return t(null,n);let o=r.reduce((I,R)=>I+R);o=o<=0?1:o;const i=n.width,a=n.height,s=n.data;let l=0,c=0,u=0;const d=Math.round(Math.sqrt(r.length)),f=Math.floor(d/2);let h=0,m=0,p=0,v=0,g=0,y=0,b=0,S=0,T=0,C=0;const x=new Uint8ClampedArray(i*a*4);for(u=0;u<a;u++)for(c=0;c<i;c++){for(h=0,m=0,p=0,v=0,y=0;y<d;y++)for(g=0;g<d;g++)b=u+y-f,S=c+g-f,b<0&&(b=a-1),b>=a&&(b=0),S<0&&(S=i-1),S>=i&&(S=0),T=(b*i+S)*4,C=r[y*d+g],h+=s[T]*C,m+=s[T+1]*C,p+=s[T+2]*C,v+=s[T+3]*C;x[l]=h/o,x[l+1]=m/o,x[l+2]=p/o,x[l+3]=v/o,l+=4}t(null,{data:x,width:i,height:a})})(Object.assign({ imageData: imageData }, filterInstructions[6]), 
                    done)
            })
            })
            })
            })
            })
            })
            })(null, imageData)
        }).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()