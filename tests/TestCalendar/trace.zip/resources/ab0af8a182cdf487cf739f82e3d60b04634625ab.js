(function () {self.onmessage = function (message) {((o,i,s)=>{createImageBitmap(o).then(a=>{let l=a.width,c=a.height;const u=l*c;if(i&&u>i){const g=Math.sqrt(i)/Math.sqrt(u);l=Math.floor(l*g),c=Math.floor(c*g)}const d=new OffscreenCanvas(l,c),f=d.getContext("2d",{willReadFrequently:!0});f.drawImage(a,0,0,l,c);const p=f.getImageData(0,0,d.width,d.height);s(null,p)}).catch(a=>{s(a)})}).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()