(function () {self.onmessage = function (message) {(function(e,t,n){createImageBitmap(e).then(function(e){var r=e.width,o=e.height,i=r*o;if(t&&i>t){var a=Math.sqrt(t)/Math.sqrt(i);r=Math.floor(r*a),o=Math.floor(o*a)}var c=new OffscreenCanvas(r,o),u=c.getContext("2d",{willReadFrequently:!0});u.drawImage(e,0,0,r,o);var l=u.getImageData(0,0,c.width,c.height);n(null,l)}).catch(function(e){n(e)})}).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()