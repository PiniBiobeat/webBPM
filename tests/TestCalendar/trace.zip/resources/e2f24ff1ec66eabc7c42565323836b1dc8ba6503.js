(function () {self.onmessage = function (message) {((o,i,a)=>{createImageBitmap(o).then(s=>{let l=s.width,c=s.height;const u=l*c;if(i&&u>i){const m=Math.sqrt(i)/Math.sqrt(u);l=Math.floor(l*m),c=Math.floor(c*m)}const d=new OffscreenCanvas(l,c),f=d.getContext("2d",{willReadFrequently:!0});f.drawImage(s,0,0,l,c);const h=f.getImageData(0,0,d.width,d.height);a(null,h)}).catch(s=>{a(s)})}).apply(null, message.data.content.concat([function (err, response) {
    response = response || {};
    const transfer = 'data' in response ? [response.data.buffer] : 'width' in response ? [response] : [];
    return self.postMessage({ id: message.data.id, content: response, error: err }, transfer);
}]))}})()