self.addEventListener("message", async (event) => {
  const { srcImage, minImageSize, maxImageSize, printableQuality, printingQualityPrintable, printingQualityLow, printingQualityUnprintable ,file} = event.data;

  if (typeof srcImage === 'string') {
    fetch(srcImage)
      .then(response => response.blob())
      .then(blob => {
        // Convert the blob to a data URL
        return [new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        }), blob];
      })
      .then(async (dataUrl)  => {
        // Set the data URL as the source
        // imageElement.src = dataUrl;
        const imageBitmap = await createImageBitmap(dataUrl[1]);

        const width = imageBitmap.width;
        const height = imageBitmap.height;
        const qualityStatus = setImageQualityStatus(width, height, minImageSize, printableQuality, printingQualityPrintable, printingQualityLow, printingQualityUnprintable);
        const needToResize = setNeedToResize(width, height, maxImageSize);

        const widthCanvas = 200; // Set the desired width
        const smallerDimension = Math.min(width, height);
        const x = (width - smallerDimension) / 2;
        const y = (height - smallerDimension) / 2;
        
        const canvas = new OffscreenCanvas(smallerDimension, smallerDimension);
        const ctx = canvas.getContext('2d');
        
        // Crop the image into a square from the center
        ctx.drawImage(imageBitmap, x, y, smallerDimension, smallerDimension, 0, 0, smallerDimension, smallerDimension);

        // Convert the canvas to a Blob
        const resizedBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.5 });
        const resizedDataUrl = URL.createObjectURL(resizedBlob);

        // Convert the Blob to a data URL
        // resizedDataUrl = await new Promise((resolve) => {
        //   const reader = new FileReader();
        //   reader.onloadend = () => resolve(reader.result);
        //   reader.readAsDataURL(resizedBlob);
        // })

        const responseData = {
          // status: response.status,
          qualityStatus: qualityStatus,
          needToResize: needToResize,
          src: resizedDataUrl,
          file: file
        };

        // Send the extracted data back to the main thread
        self.postMessage(responseData);
      })
      .catch(error => console.error('Error loading image data:', error));
  }

  // try {
  //   const response = await fetch(srcImage);
  //   if (!response.ok) {
  //     throw new Error('Failed to fetch image');
  //   }

  //   const blob = await response.blob();

  //   // Create an image bitmap from the blob
  //   const imageBitmap = await createImageBitmap(blob);

  //   const width = imageBitmap.width;
  //   const height = imageBitmap.height;

  //   const qualityStatus = setImageQualityStatus(width, height, minImageSize, printableSize, printable, low, unprintable);
  //   const needToResize = setNeedToResize(width, height, maxImageSize);

  //   const responseData = {
  //     status: response.status,
  //     qualityStatus: qualityStatus,
  //     needToResize: needToResize
  //   };

  //   // Send the extracted data back to the main thread
  //   self.postMessage(responseData);
  // } catch (error) {
  //   self.postMessage({ error: error.message });
  // }
});

const setImageQualityStatus = (width, height, minImageSize, printableSize, printable, low, unprintable) => {
  if (
    width >= printableSize &&
    height >= printableSize
  ) {
    return printable;
  } else if (
    width >= minImageSize &&
    height >= minImageSize
  ) {
    return low;
  } else {
    return unprintable;
  }
};

const setNeedToResize = (width, height, maxImageSize) => {
  if (
    width < maxImageSize ||
    height < maxImageSize
  ) {
    return false;
  }
  return true;
};