let isProcessing = false;
const queue = [];

self.addEventListener("message", async (event) => {
    const { files, imgResizeSize, imgResizeQuality, batchSize } = event.data;
    const batches = [];
    for (let i = 0; i < files.length; i += batchSize) {
        batches.push(files.slice(i, i + batchSize));
    }

    // Add batches to the queue
    queue.push(...batches);

    // If no processing is currently ongoing, start processing
    if (!isProcessing) {
        processNext(imgResizeSize, imgResizeQuality);
    }
});

async function processNext(imgResizeSize, imgResizeQuality) {
    // If the queue is empty, stop processing
    if (queue.length === 0) {
        isProcessing = false;
        return;
    }

    isProcessing = true;
    const batch = queue.shift(); // Get the next batch from the queue

    try {
        const resizedBlobs = await Promise.all(batch.map(async (file) => {
            return await resizeImageWithDims(file, imgResizeSize, imgResizeQuality);
        }));
        self.postMessage({ resizedBlobs });

        // Process the next batch in the queue
        processNext();
    } catch (error) {
        self.postMessage({ error: error.message });

        // Process the next batch in the queue even if an error occurred
        processNext();
    }
}

async function resizeImageWithDims(file, imgResizeSize, imgResizeQuality) {
    try
    {
        return new Promise(async (resolve) => {
            const blob = new Blob([file.file], { type: file.type });
            const img = await createImageBitmap(blob);

            let imgWidth = img.width;
            let imgHeight = img.height;

            if (imgWidth > imgResizeSize || imgHeight > imgResizeSize) {
                if (imgWidth > imgHeight) {
                    imgHeight *= imgResizeSize / imgWidth;
                    imgWidth = imgResizeSize;
                } else {
                    imgWidth *= imgResizeSize / imgHeight;
                    imgHeight = imgResizeSize;
                }
            }

            const canvas = new OffscreenCanvas(imgWidth, imgHeight);
            const ctx = canvas.getContext('2d');

            canvas.width = imgWidth;
            canvas.height = imgHeight;

            ctx.drawImage(img, 0, 0, imgWidth, imgHeight);
            const resizedBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: imgResizeQuality });

            resolve({file: resizedBlob, blobSrc: file.blobSrc});
        });
    }
    catch(error)
    {
        console.log(error);
        console.log(file.blobSrc);
        resolve({file: file.file, blobSrc: file.blobSrc});
    }
}
