// self.onmessage = async (event) => {
//   const { file, token, calendarToken } = event.data;

//   try {
//     let upload_file = new File([file], "filename");
//     let formData = new FormData();
//     formData.append("file", upload_file);
//     const response = await fetch(
//       `http://calendarv4-api.lupa.co/upload-browser.aspx?token=${token}&event_token=${calendarToken}`,
//       {
//         method: "POST",
//         body: formData,
//       }
//     );

//     // Send the response back to the main thread
//     self.postMessage(response);
//   } catch (error) {
//     // Send the error back to the main thread
//     self.postMessage({ error: error.message });
//   }
// };
// self.addEventListener("message", async (event) => {
//   const { file, token, calendarToken, blobSrc } = event.data;

//   try {
//     let upload_file = new File([file], "filename");
//     let formData = new FormData();
//     formData.append("file", upload_file);
//     const response = await fetch(
//       // `https://calendarv4-api.lupa.co/dev/upload-browser.aspx?token=${token}&event_token=${calendarToken}`,
//       `https://calendarv4-api.lupa.co/upload-browser.aspx?token=${token}&event_token=${calendarToken}&blobSrc=${blobSrc}`,
//       {
//         method: "POST",
//         body: formData,
//       }
//     );

//     const responseData = {
//       status: response.status,
//       headers: Array.from(response.headers.entries()),
//       data: await response.text(), // Adjust this based on the response data type
//     };

//     // Send the extracted data back to the main thread
//     self.postMessage(responseData);
//   } catch (error) {
//     // Send the error back to the main thread
//     self.postMessage({ error: error.message });
//   }
// });


self.addEventListener("message", async (event) => {
  const { files, token, calendarToken, blobSrc } = event.data;

  try {
    let formData = new FormData();
    for (const file of files) {
      if (file.file instanceof File) {
          formData.append("files[]", file.file);
      } else if (file instanceof File) {
          formData.append("files[]", file);
      }
  }

    // Make a single fetch request with FormData containing all images
    const response = await fetch(
      `https://calendarv4-api.lupa.co.il/upload-browser.aspx?token=${token}&event_token=${calendarToken}&blobSrc=${blobSrc}`,
      {
        method: "POST",
        body: formData,
      }
    );

    const responseData = {
      status: response.status,
      headers: Array.from(response.headers.entries()),
      data: await response.text(), // Adjust this based on the response data type
    };

    // Send back response for the entire batch
    self.postMessage({ responses: [responseData] });
  } catch (error) {
    self.postMessage({ error: error.message });
  } finally {
    // Notify the main thread that the batch upload is done
    self.postMessage("done");
  }
});
