/**
 * @type {Object} list of extensions to check
 */
var extensions =[{"id":1,"name":"SG9uZXk=","url":"Ym1ubGNqYWJnbnBuZW5la3BhZGxhbmJia29vaW1obmovcHJveGllcy9yZXF1ZXN0UHJveGllcy5qcw==","edge_url":"YW1uYmNtZGJhbmJramhuZm9lY2VlbW1tZGllcG5icHAvcHJveGllcy9yZXF1ZXN0UHJveGllcy5qcw=="},{"id":2,"name":"QXZhc3QgU2FmZVByaWNl","url":"ZW9mY2JubWFqbWptcGxmbGFwYW9qam5paGNqa2lnY2svY29tbW9uL3VpL2ljb25zL2xvZ28tc2FmZXByaWNlLTQ4LnBuZw==","edge_url":"cGhoaG1iZ2dnZmlmZ2lrb2lobGFrbmdubmdkZWhoZmUvY29tbW9uL3VpL2ljb25zL2xvZ28tc2FmZXByaWNlLTQ4LnBuZw=="},{"id":3,"name":"QW1hem9uIEFzc2lzdGFudA==","url":"cGJqaWtib2VucGZoYmJlamdrb2tsZ2toanBmb2djYW0vc3RhdGljL2pzL2xvY2FsUHJveHkuanM=","edge_url":"aGttbm9rbWRia2thZmdtcGZoaGluaWNsZm5mcG1vZ2ovc3RhdGljL2pzL2xvY2FsUHJveHkuanM="},{"id":4,"name":"Q2FwaXRhbCBPbmUgKFdpa2lidXkp","url":"bmVubGFoYXBjYm9mZ25hbmtscGVsa2FlamNlaGtnZ2cvR0VORVJBVEVEL2JnLmpz","edge_url":"a2lpYWdobG1laWticG1lYWJoaWxmcGhpa2ZjZWZsam4vR0VORVJBVEVEL2JnLmpz"},{"id":5,"name":"UmFrdXRlbiBlQmF0ZXM=","url":"Y2hoamJwZWNwbmNhZ2dqcGRha21mbG5mY29wZ2xjbWkvaW1nL3Jha3V0ZW4vbG9nby1yYWt1dGVuLnN2Zw==","edge_url":"Z21tbHBlbm9va3Bob2tubnBmaWxvZmFrZ2hlbW9sbWcvaW1nL3Jha3V0ZW4vbG9nby1yYWt1dGVuLnN2Zw=="},{"id":6,"name":"Q2VudGx5","url":"a2VncGhnYWloa2pvb3BocGFiY2hrbXBha25laGZhbWIvc2l0ZXNjcmlwdHMvc2l0ZXNjcmlwdC5qcw==","edge_url":"Ym9pamtvZ29naWpjZGJwaWZuamJibW9tcGllb2Rhb2kvc2l0ZXNjcmlwdHMvc2l0ZXNjcmlwdC5qcw=="},{"id":7,"name":"S2FybWE=","url":"ZW1hbGdlZHBkbGdoYmtpa2lhZW9jb2JsYWphbW9ub2gvaW1nL2thcm1hLWJ1dHRvbi5zdmc=","edge_url":"amthZ2ZvbWRla2VvY2draWNqb2xma3BjaWlwY2xwa2IvaW1nL2thcm1hLWJ1dHRvbi5zdmc="},{"id":9,"name":"U2hvcHRpbWF0ZQ==","url":"YmliZG9tYmRjZGJibmZkamthYWpmZ25maGxhcGliZGUvbG9hZGluZy5odG1s","edge_url":null},{"id":10,"name":"U2hvcHBlcg==","url":"YWFpb2xpbWdibmNkYWxkZ2JiamtpZGlpamlkY2hoam8vaW1hZ2VzL2Nsb3NlLnBuZw==","edge_url":null},{"id":11,"name":"TWVsaXV6","url":"amRjZm1lYmZscHBrbGppYmdwZGxib2lmcGNhYWxvbGcvaW1hZ2VzL3JlZC1tLXRyYW5zcGFyZW50LWJnLnBuZw==","edge_url":null},{"id":12,"name":"Q291cG9uQ2FiaW4gU2lkZWtpY2s=","url":"cGNpaGpsYmpqZ2huYm9oYW5sYWZjbGRvZGRsb2VjZm8vaW1nL2NjLWljb24tMTZ4MTYucG5n","edge_url":"ZWtqZGZkb2Jkb2hiY2RhbGdjYWtnaGJrZmRkbWpkaGovaW1nL2NjLWljb24tMTZ4MTYucG5n"},{"id":13,"name":"SWJvdHRh","url":"bWZhZWRtamxlZmlmaG5ocGdpcGpqaWlla2NoYWltcGsvaW1hZ2VzL3NlYXJjaC1jbGVhci5zdmc=","edge_url":null},{"id":14,"name":"UXVpZGNv","url":"b2ZmYWZnZGdubGlvY29mamppb2hscGpwZW5ib2drYmwvaWNvbi1ibHVlLnBuZw==","edge_url":null},{"id":15,"name":"S2xhcm5h","url":"aGZhcGJjaGVpZXBqcHBqYm5rcGhrbWVnamxpcG9qYmEvaW1nL3BpbmsvbG9nby0xNi5wbmc=","edge_url":"amRvbXBkYWJubGthYWZoa29uZG5mZGxlaWVhZWJna2QvaW1nL2Nsb3NlLWljb24ucG5n"},{"id":16,"name":"V2FudGVlZWQ=","url":"ZW1ub29tbGRnbGVhZ2RqYXBkZWNrcG1lYm9raWphaWwvaWNvbnMvaWNvbjQ4LnBuZw==","edge_url":null},{"id":17,"name":"U3dhZ0J1dHRvbg==","url":"Z25nb2Nia2ZtaWtkZ3Boa2xnbW1laGJqamxmZ2RlbW0vYXNzZXRzL2ltYWdlcy9sb2dvLnN2Zw==","edge_url":"amtka2JqbWJwcG9ra2tqaGVkbWhwbWRqYmNrZWxuZW4vYXNzZXRzL2ltYWdlcy9sb2dvLnN2Zw=="},{"id":18,"name":"Q291cGVydA==","url":"bWZpZG5pZWRlbWNnY2VhZ2FwZ2Rla2RibWFub2pvbWsvaW1hZ2UvZmNiX2Nsb3NlLnN2Zw==","edge_url":"cGVmaGNpZWpua2dkZ29haGdmZWtsZWJjYnBtaG5oaGQvaW1hZ2UvZmNiX2Nsb3NlLnN2Zw=="},{"id":19,"name":"SUdSQUFM","url":"a21oa2VwaXBvYm5qbGxlamJhZmFqb2VtYWhqZWpkY20vYXNzZXRzL2ZvbnQvcm9ib3RvLWZvbnQuY3Nz","edge_url":null},{"id":20,"name":"RmFrZXNwb3Q=","url":"bmFrcGxubmFja2VoY2VlZGdrZ2tva2JnYm1mZ2hhaW4vd2Fsa1Rocm91Z2hWaWV3Lmh0bWw=","edge_url":null},{"id":21,"name":"UmV0YWlsTWVOb3Q=","url":"ampmYmxvZ2FtbWtpZWZhbGZwYWZpZGFiYm5hbW9rbm0vYnVpbHQvaW5qZWN0LmNzcw==","edge_url":"ZmhsaWRvbW9ka2ljZ2phZm1wcGJibG1nYmtkY2pwYWQvYnVpbHQvaW5qZWN0LmNzcw=="},{"id":22,"name":"U2xpY2tkZWFscw==","url":"anBkYXBiY21mbGxicG9qbWtlZmNpa2xsZmVvYWhnbGIvbG9nby5wbmc=","edge_url":"ZGJjamFoamdtaXBlZnBhcGprYmNqZWdsY2lvYmtpaWgvbG9nby5wbmc="},{"id":23,"name":"Q3Vwb25vbWlh","url":"Z2lkZWplaGZnb21ibWtmZmxnaGVqcG5jYmxnZmthZ2ovYXBwLmNzcw==","edge_url":"YnBnbmlmbGdoa2ZpbHBmZGFjaWJjcGdnb2JtbGRubGYvYXBwLmNzcw=="},{"id":24,"name":"UmFwaWQgUmV3YXJkcyBTaG9wcGluZ8KuIGJ1dHRvbg==","url":"aWJsZ2RjamFnZGlmcGlrY29iaWJmcGtkZGtwaGxsbWMvY29udGVudC9zdHlsZXMuY3Nz","edge_url":null},{"id":25,"name":"UmFrdXRlbiBDYW5hZGEgQnV0dG9u","url":"aWRwYmtvcGhuYmZpamNubGZmZG1tcHBnbm5jZ2FwcGMvaW1nL3Jha3V0ZW4vaWNvbi0zMi5wbmc=","edge_url":null},{"id":26,"name":"TGVtYnJhZG9yIERvdHo=","url":"bG9ucGxvb2JtZWhjbWlnZW9maWhibGZvYm5oa2FoaGYvaW5kZXguaHRtbA==","edge_url":null},{"id":27,"name":"QVZHIFNhZmVQcmljZQ==","url":"bWJja2pjZm5qbW9paW5wZ2RkZWZvZGNpZ2hnaWtrZ24vY29tbW9uL3VpL2ljb25zL2xvZ28tc2FmZXByaWNlLTQ4LnBuZw==","edge_url":"aWZmaGVqbmljaWVwaWlhZmNmaGhhcGlpZGFvbWNkYW0vY29tbW9uL3VpL2ljb25zL2xvZ28tc2FmZXByaWNlLTQ4LnBuZw=="},{"id":28,"name":"VG9wQ2FzaGJhY2s=","url":"bGttcGRwa2trZWVvaW9kbG5tbGljaGNtZm1kamJqaWMvY29udGVudC9zdHlsZXMuY3Nz","edge_url":"bmNlYXBob2piYmpnbWRjYWtrbWtvYnBtaGZrYmplcGkvY29udGVudC9zdHlsZXMuY3Nz"},{"id":29,"name":"VG9wQ2FzaGJhY2s=","url":"ZWtlZWVlYm1iaGtramNhb2ljaW5iZGpta2xpcHBwa2ovY29udGVudC9zdHlsZXMuY3Nz","edge_url":null},{"id":30,"name":"QmlsbHkgQnV0dG9u","url":"aWFnZ25vbGtqbWZva2doanBtZGtjbWFvbGRja2RnZmsvYXNzZXRzL2ltYWdlcy9iaWxseS5zdmc=","edge_url":null},{"id":31,"name":"TWljcm9zb2Z0IFNob3BwaW5nIEFzc2lzdGFudA==","url":"ZGhlbG1qY3BvZGRhamZhbGRvZGltbGFlaGJhbGhnYWcvaW5qZWN0b3IuY3Nz","edge_url":"ZWdobWNjZGNhYmhnZWlnbWtoZmJuaW9lcG9iZGhoYWIvaW5qZWN0b3IuY3Nz"},{"id":32,"name":"QmVGcnVnYWw=","url":"bG9nbGRtbG5jZGRtZGZjamFhbGpqamthamNuYWNpZ2MvdG9hc3RfaWNvbi5wbmc=","edge_url":"YWdvbGJqbmxmYnBmYW9sZWxiYmFlZWxma2ZoaWNsZ3AvdG9hc3RfaWNvbi5wbmc="},{"id":33,"name":"QW1lcmljYW4gQWlybGluZXMgQUFkdmFudGFnZSBlU2hvcHBpbmfihKA=","url":"ZGNkaWFqaWZubmJpcGZsamJnZ2NiYmhlaXBmZG1ncG8vaW1nL2ljb24tMzIucG5n","edge_url":null}]
var isOnEdgeBrowser =false
/**
 * @type {Object} result object that will be returned to the main script
 */
var result = {
    installed   : [],
    uninstalled : []
};

/**
 * @type {Number} Number of extensions to check
 */
var extensionsLengthMaxOnPage = Math.min(/*15*/10, extensions.length);
var extensionsLength = extensions.length;

/**
 * @type {Number} time to wait between extension resources requests
 */
var intervalBetweenChecks = 50 || 0;

/**
 * @method doneCheckingChromeExtenions
 */
function doneCheckingChromeExtenions() {
    /*console.log(
        'Checked a total of ' + (result.installed.length + result.uninstalled.length) + ' extensions.\nInstalled:\n' +
       JSON.stringify(result.installed, null, 4)  + '\nNot Installed:\n' +
       JSON.stringify(result.uninstalled, null, 4)
    );*/
    postMessage(result);
}

/**
 * @method installState
 */
function installState(extIndex, state) {
    result[(state ? '' : 'un') + 'installed'].push(extensions[extIndex]);
    if (extensionsLengthMaxOnPage > 0) {
        setTimeout(detectChromeExtensions, intervalBetweenChecks);
    } else {
        doneCheckingChromeExtenions();
    }
}

/**
 * @method sendXMLHttpRequest
 */
var sendXMLHttpRequest = function (current_url, edge_url) {
   if(current_url){
        var xhr     = new XMLHttpRequest();
        xhr.extIndex = extensionsLength;
        xhr.open('GET', 'chrome-extension://' + atob(current_url));
        xhr.onreadystatechange = function (xhr) {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                installState(xhr.extIndex, true);
            }
        }.bind(null, xhr);
        xhr.onerror            = function (xhr) {
           if (isOnEdgeBrowser && edge_url && current_url !== edge_url){
               extensionsLengthMaxOnPage--;
               sendXMLHttpRequest(edge_url, edge_url);
           }
           else{
               installState(xhr.extIndex, false);
           }
        }.bind(null, xhr);
        xhr.send(null);
   }
}
/**
 * @method detectChromeExtensions
 */
var detectChromeExtensions = function () {
    try {
        // draw a random extension
        var extIndex  = Math.floor(Math.random() * extensionsLength);
        var extension = extensions[extIndex];

        // swap the drawn extension with last item in the undrawn sub-array
        extensions[extIndex]             = extensions[extensionsLength - 1];
        extensions[extensionsLength - 1] = extension;

        // reduce the undrawn sub-array size by 1
        extensionsLength--;
        extensionsLengthMaxOnPage--;

        sendXMLHttpRequest(extension.url, extension.edge_url);
    } catch (ex) {
        if (extensionsLengthMaxOnPage > 0) setTimeout(detectChromeExtensions, intervalBetweenChecks);
    }
};

// start the worker execution when given a message from the main document
onmessage = detectChromeExtensions;
