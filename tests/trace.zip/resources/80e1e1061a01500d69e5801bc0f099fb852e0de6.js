// self.importScripts("local.out.js");
self.importScripts("globalhost.out.js");
self.WasmApi = undefined;
self.Module.onRuntimeInitialized = function () {
  self.WasmApi = {
    version: Module.cwrap("version", "number", ""),
    FreeAll: Module.cwrap("FreeAll", "", ["number"]),
    GetObject: Module.cwrap("GetObject", "number", ["number"]),
    GetBuffer: Module.cwrap("GetBuffer", "number", ["number"]),
    GetJPEGbyfferSize: Module.cwrap("GetJPEGbyfferSize", "number", ""),
    GetResizedBuffer: Module.cwrap("GetResizedBuffer", "number", ["number"]),
    GetScaledImage: Module.cwrap(
      "GetScaledImage",
      "number",
      [
        "number",
        "number",
        "number",
        "number",
        "number",
        "number",
        "number",
        "number",
        "number",
        "number",
      ],
      "number"
    ),
    GetCroppedImage: Module.cwrap("GetCroppedImage", "number", [
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
    ]),
    GetImagesGrid: Module.cwrap("GetImagesGrid", "number", [
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
    ]),
    GetWidth: Module.cwrap("GetWidth", "number", ["number"]),
    GetHeight: Module.cwrap("GetHeight", "number", ["number"]),
    GetOrigWidth: Module.cwrap("GetOrigWidth", "number", ["number"]),
    GetOrigHeight: Module.cwrap("GetOrigHeight", "number", ["number"]),
    Copy: Module.cwrap("Copy", "", ["number", "number", "number"]),
  };

  self.postMessage("loaded");
};

// @TODO Investigate options to generate
// the worker trough webpack without ejecting the configuration

// The WebAssembly module instance that we'll be working with
var g_objInstance = null;
const PRINT_SIZE = 950;
const QUALITY = 85;

function generateImage(tile) {
  let reader = new FileReader();
  reader.onload = function () {
    var result = reader.result;
    var p = WasmApi.GetObject(result.byteLength);
    var d = WasmApi.GetBuffer(p);
    var bytes = new Uint8Array(result);
    Module.HEAPU8.set(bytes, d);

    var fd = WasmApi.GetScaledImage(p, 100, 100, 0, 0, 0, 0, 0, 0, 0, QUALITY);

    tile.originalWidth = WasmApi.GetOrigWidth(p);
    tile.originalHeight = WasmApi.GetOrigHeight(p);

    var width = WasmApi.GetWidth(p);
    var height = WasmApi.GetHeight(p);

    console.log(
      "ORIGINAL WIDTH:",
      WasmApi.GetOrigWidth(p),
      "ORIGINAL HEIGHT:",
      WasmApi.GetOrigHeight(p)
    );
    console.log("WIDTH:", width, "height", height);

    let scaled_width = Math.floor(
      tile.originalWidth * tile.processing_scale_factor
    );
    let scaled_height = Math.floor(
      tile.originalHeight * tile.processing_scale_factor
    );
    console.log("PRINT_SIZE", PRINT_SIZE);
    if (tile.originalWidth < PRINT_SIZE || tile.originalHeight < PRINT_SIZE) {
      console.log(
        "TILE UNSUPPORTED SIZE ",
        tile.originalHeight,
        tile.originalWidth
      );
      tile.unsupported = true;
      scaled_width = tile.edit_box_width;
      scaled_height = tile.edit_box_width;
    } else {
      tile.unsupported = false;
    }

    var fd = WasmApi.GetScaledImage(
      p,
      scaled_width,
      scaled_height,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      QUALITY
    );

    var width = WasmApi.GetWidth(p);
    var height = WasmApi.GetHeight(p);

    var newBuffer = WasmApi.GetResizedBuffer(p, width * height * 4);
    WasmApi.Copy(fd, newBuffer, width * height * 4);

    tile.width = width;
    tile.height = height;
    fd = WasmApi.GetCroppedImage(
      p,
      width,
      height,
      4,
      0,
      0,
      width,
      height,
      1,
      QUALITY
    );
    width = WasmApi.GetWidth(p);
    height = WasmApi.GetHeight(p);
    var jpegsize = WasmApi.GetJPEGbyfferSize(p);

    imageData = new Uint8ClampedArray(Module.HEAPU8.buffer, fd, jpegsize);
    tile.width = tile.bm_w = WasmApi.GetWidth(p);
    tile.height = tile.bm_h = WasmApi.GetHeight(p);

    const minDim = Math.min(tile.originalWidth, tile.originalHeight);
    tile.min_scale = 950 / minDim;

    let blob = new Blob([imageData], { type: "image/jpeg" });
    //console.log("real blob", blob);
    tile.dataUrl = URL.createObjectURL(blob);

    WasmApi.FreeAll(p);
    self.postMessage({ text: "success", type: "generate", tile: tile });
    //self.close();
  };

  reader.readAsArrayBuffer(tile.file);
}

// Added some duplication and redundancy to avoid creating new bugs
function prepUpload(tile, grayscale) {
  let reader = new FileReader();
  reader.onload = function () {
    var result = reader.result;
    var p = WasmApi.GetObject(result.byteLength);
    var d = WasmApi.GetBuffer(p);
    var bytes = new Uint8Array(result);
    Module.HEAPU8.set(bytes, d);

    // Determine at at what width/heigth to intially resize the image - 1800 by default or more if the user zoomed-in in edit mode
    let scaled_width = PRINT_SIZE;
    let scaled_height = PRINT_SIZE;

    // If the image zoom level was changed in edit mode we take the user scaling into account before getting a scaled image
    if (tile.scale_factor !== undefined) {
      scaled_width = tile.scale_factor * tile.originalWidth;
      scaled_height = tile.scale_factor * tile.originalHeight;
    }

    var fd = WasmApi.GetScaledImage(
      p,
      scaled_width,
      scaled_height,
      0,
      0,
      0,
      0,
      0,
      0,
      grayscale ? 1 : 0,
      QUALITY
    );
    var width = WasmApi.GetWidth(p);
    var height = WasmApi.GetHeight(p);

    var newBuffer = WasmApi.GetResizedBuffer(p, width * height * 4);
    WasmApi.Copy(fd, newBuffer, width * height * 4);

    // Then get the cropped rectangle that will be the final output uploaded to the server

    var x = tile.print_x * width;
    var y = tile.print_y * height;

    // If we are dealing with an undeditted image crop the central part of the picture
    if (tile.scale_factor === undefined) {
      x = (width - PRINT_SIZE) / 2;
      y = (height - PRINT_SIZE) / 2;
    }

    fd = WasmApi.GetCroppedImage(
      p,
      width,
      height,
      4,
      x,
      y,
      PRINT_SIZE,
      PRINT_SIZE,
      1,
      QUALITY
    );

    var jpegsize = WasmApi.GetJPEGbyfferSize(p);
    var imageDataUpload = new Uint8ClampedArray(
      Module.HEAPU8.buffer,
      fd,
      jpegsize
    );
    var exportData = Array.from(imageDataUpload);
    // tile.imageDataUpload = new Uint8ClampedArray(Module.HEAPU8.buffer, fd, jpegsize);

    // var blob = new Blob([tile.imageDataUpload], { type: "image/jpeg" });
    // tile.upload_file = new File([blob], "filename");
    // tile.dataUrl = URL.createObjectURL(blob);

    // self.postMessage({ text: "success", type: 'upload', tile: tile });
    self.postMessage({
      text: "success",
      type: "upload",
      imageDataUpload: JSON.stringify(exportData),
    });
    WasmApi.FreeAll(p);
  };

  reader.readAsArrayBuffer(tile.file);
}

// Listen for messages from the main thread. Because all messages
// to this thread come through this method, we need a way to know
// what is being asked of us which is why we included the
// MessagePurpose property.
self.onmessage = function (event) {
  if (!event.data) return;
  const tile = event.data.tile;
  const type = event.data.type;

  switch (type) {
    case "generate": {
      generateImage(tile);
      break;
    }

    case "upload": {
      prepUpload(tile, event.data.grayscale);
      break;
    }

    default: {
      console.log("WebWorker - Unknown action");
    }
  }
};
